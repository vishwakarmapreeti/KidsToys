import { Router } from 'express';
import {
  createProduct, getProducts, getProduct,
  getProductBySlug, updateProduct, deleteProduct,
  getProductsByCategory,
} from '@controllers/productController';
import { protect, adminOnly } from '@middleware/authMiddleware';
import upload from '@middleware/upload';

const router = Router();

router.get('/',                    getProducts);
router.get('/category/:catId',     getProductsByCategory);
router.get('/slug/:slug',          getProductBySlug);
router.get('/:id',                 getProduct);
router.post('/',   protect, adminOnly, upload.array('images', 5), createProduct);
router.put('/:id', protect, adminOnly, upload.array('images', 5), updateProduct);
router.delete('/:id', protect, adminOnly, deleteProduct);

export default router;