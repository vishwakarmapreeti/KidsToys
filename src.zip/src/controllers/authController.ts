import { Request, Response } from 'express';
import User from '../models/User';
import generateToken from '../utils/generateToken';
import { AuthRequest } from '../types';

const cookieOptions = {
  httpOnly: true,
  secure: process.env.NODE_ENV === 'production',
  sameSite: 'strict' as const,
  maxAge: 7 * 24 * 60 * 60 * 1000,
};

// @route  POST /api/auth/register
export const register = async (req: Request, res: Response): Promise<void> => {
  try {
    const { name, email, password, phone, address ,adminSecret } = req.body;

    const userExists = await User.findOne({ email });
    if (userExists) {
      res.status(400).json({ message: 'Email already registered' });
      return;
    }


       let role: 'user' | 'admin' = 'user';
    if (adminSecret) {
      if (adminSecret === process.env.ADMIN_SECRET) {
        role = 'admin';
      } else {
        res.status(403).json({ message: 'Invalid admin secret key' });
        return;
      }
    }

    const user = await User.create({
      name,
      email,
      password,
      phone,
      address,
    });

    const token = generateToken(user._id.toString(), user.role);

    res.cookie('token', token, cookieOptions);
    res.status(201).json({
      success: true,
      user: {
        id:      user._id,
        name:    user.name,
        email:   user.email,
        phone:   user.phone,
        address: user.address,
        role:    user.role,
      },
      token,
    });
  } catch (error) {
    res.status(500).json({ message: (error as Error).message });
  }
};

// @route  POST /api/auth/login
export const login = async (req: Request, res: Response): Promise<void> => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email }).select('+password');
    if (!user || !(await user.comparePassword(password))) {
      res.status(401).json({ message: 'Invalid email or password' });
      return;
    }

    const token = generateToken(user._id.toString(), user.role);

    res.cookie('token', token, cookieOptions);
    res.json({
      success: true,
      user: { id: user._id, name: user.name, email: user.email, role: user.role },
      token,
    });
  } catch (error) {
    res.status(500).json({ message: (error as Error).message });
  }
};

// @route  POST /api/auth/logout
export const logout = (req: Request, res: Response): void => {
  res.cookie('token', '', { maxAge: 0 });
  res.json({ success: true, message: 'Logged out successfully' });
};

// @route  GET /api/auth/me  (protected)
export const getMe = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const user = await User.findById(req.user?._id);
    res.json({ success: true, user });
  } catch (error) {
    res.status(500).json({ message: (error as Error).message });
  }
};